// Cloudflare dashboard build command: node vocaquest-cloudflare-build.mjs
// Build variable: VOCAQUEST_D1_ID = the ID of your existing vocaquest-db database.
// Deploy command: npm run deploy:cloudflare
// This script prepares and builds the game. It never starts an interactive login.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';

const archive = 'VocaQuest-Cloudflare-update.zip';
const patch = 'VocaQuest-update/update.patch';
const archiveHash = '79a715c7cb5cbdca4f0146e3b25addb4c87560df648f144f852d6540d0704aa5';
const patchHash = '460b1361f935aa6c207c33f84d96cb152db0e16e9230bdd195b238ea46308569';
const accountId = '3332515a8819ec6238d719a2c85d698d';
const placeholder = '00000000-0000-4000-8000-000000000000';
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function fail(message) { throw new Error(message); }
function readJson(path) { return JSON.parse(readFileSync(path, 'utf8')); }
function run(command, args) {
  const result = spawnSync(command, args, { stdio: 'inherit', env: process.env });
  if (result.error) throw result.error;
  if (result.status !== 0) fail(`${command} failed; deployment stopped. See the preceding error.`);
}
function checkHash(path, expected) {
  const actual = createHash('sha256').update(readFileSync(path)).digest('hex');
  if (actual !== expected) fail(`${path} does not match the verified VocaQuest update.`);
}

try {
  if (process.argv.slice(2).some(arg => arg !== '--prepare-only')) fail('Unknown option.');
  if (!existsSync('package.json') || !existsSync('app/page.tsx')) {
    fail('Run this build from the VocaQuest repository root.');
  }
  const existing = existsSync('wrangler.json') ? readJson('wrangler.json') : {};
  const databaseId = (process.env.VOCAQUEST_D1_ID || existing.d1_databases?.find(d => d.binding === 'DB')?.database_id || '').trim();
  if (!uuid.test(databaseId) || databaseId === placeholder) {
    fail('Add VOCAQUEST_D1_ID in Cloudflare Settings > Build > Variables and secrets. Use the Database ID from your existing vocaquest-db database.');
  }
  if (process.env.CLOUDFLARE_ACCOUNT_ID && process.env.CLOUDFLARE_ACCOUNT_ID !== accountId) {
    fail('This build belongs to Amina Qatan’s VocaQuest Cloudflare account. Check the selected account.');
  }
  const alreadyUpdated = existsSync('app/auth.ts') && existsSync('app/api/session/route.ts') &&
    existsSync('lib/audio-storage.ts') && existsSync('scripts/cloudflare-deploy.mjs') &&
    readJson('package.json').scripts?.['deploy:cloudflare'] === 'node scripts/cloudflare-deploy.mjs';
  if (!alreadyUpdated) {
    if (!existsSync(archive)) fail(`Upload ${archive} to the repository root first.`);
    checkHash(archive, archiveHash);
    run('unzip', ['-o', archive]);
    checkHash(patch, patchHash);
    run('git', ['apply', '--check', patch]);
    run('git', ['apply', patch]);
    console.log('Applied the verified standalone VocaQuest update.');
  }
  if (existsSync('app/chatgpt-auth.ts') || !existsSync('app/sign-in/page.tsx')) {
    fail('The standalone sign-in update is incomplete. Deployment stopped.');
  }
  // Repair the failed, unapplied 0002 migration without changing earlier migrations.
  // The matching storage adapter keeps quota updates atomic with each recording.
  const databaseRepair = [
  {
    "path": "drizzle/0002_cloudflare_accounts.sql",
    "originalHash": "ac11e53721015e50b16eab2a6be4a74f7ed972fede195277431cbba6ef928eff",
    "fixedHash": "0a99d7fdac0947fd58fb0bd69f1ef3ba166185c1d5c1fba2b99a1bc1d109827a",
    "contents": "CREATE TABLE sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('student','teacher')), teacher_version TEXT, expires_at INTEGER NOT NULL);\nCREATE INDEX sessions_expiry ON sessions(expires_at);\nCREATE TABLE student_keys (key_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES profiles(user_id));\nCREATE TABLE auth_attempts (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires_at INTEGER NOT NULL);\nCREATE INDEX attempts_expiry ON auth_attempts(expires_at);\nCREATE TABLE audio_budget (id INTEGER PRIMARY KEY CHECK(id=1), used_bytes INTEGER NOT NULL DEFAULT 0, max_bytes INTEGER NOT NULL DEFAULT 209715200, CONSTRAINT recording_storage_limit CHECK(used_bytes >= 0 AND used_bytes <= max_bytes));\nINSERT INTO audio_budget(id) VALUES(1);\nCREATE TABLE audio_objects (key TEXT PRIMARY KEY, size INTEGER NOT NULL, mime TEXT NOT NULL, chunks INTEGER NOT NULL);\nCREATE TABLE audio_chunks (key TEXT NOT NULL REFERENCES audio_objects(key) ON DELETE CASCADE, part INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY(key,part));\n"
  },
  {
    "path": "lib/audio-storage.ts",
    "originalHash": "d672b1e796c14cbd5429bcdeca80e68c84bcfe812aa28a5dd059ddef36602d09",
    "fixedHash": "7445441d3a6abdb6fe202f895376642157b4b935cf83bbcfbf930c24367ce5a6",
    "contents": "import {Buffer} from 'node:buffer';\nimport {db} from './session';\nconst CHUNK=512*1024;\n// Bounded short recordings share the Free D1 database. No R2 subscription is needed.\nexport function recordingStorage(){return {\n  async put(key:string,bytes:ArrayBuffer,options:{httpMetadata:{contentType:string}}){\n    const count=Math.ceil(bytes.byteLength/CHUNK);\n    const statements=[\n      db().prepare('UPDATE audio_budget SET used_bytes=used_bytes+? WHERE id=1').bind(bytes.byteLength),\n      db().prepare('INSERT INTO audio_objects(key,size,mime,chunks) VALUES(?,?,?,?)').bind(key,bytes.byteLength,options.httpMetadata.contentType,count)\n    ];\n    for(let part=0;part<count;part++)statements.push(db().prepare('INSERT INTO audio_chunks(key,part,data) VALUES(?,?,?)').bind(key,part,Buffer.from(bytes.slice(part*CHUNK,(part+1)*CHUNK)).toString('base64')));\n    try{await db().batch(statements);}catch(error){\n      if(String(error).includes('recording_storage_limit'))throw new Error('Recording storage is full. Ask your teacher to remove old recordings.');\n      throw error;\n    }\n  },\n  async get(key:string){\n    const object=await db().prepare('SELECT size,chunks FROM audio_objects WHERE key=?').bind(key).first<{size:number;chunks:number}>();\n    if(!object)return null;\n    let part=0;\n    const body=new ReadableStream<Uint8Array>({async pull(controller){\n      try{\n        if(part>=object.chunks){controller.close();return;}\n        const chunk=await db().prepare('SELECT data FROM audio_chunks WHERE key=? AND part=?').bind(key,part++).first<{data:string}>();\n        if(!chunk)throw new Error('Recording is no longer available.');\n        controller.enqueue(Buffer.from(chunk.data,'base64'));\n      }catch(error){controller.error(error);}\n    }});\n    return {body,size:object.size};\n  },\n  async delete(keys:string|string[]){\n    const list=Array.isArray(keys)?keys:[keys];if(!list.length)return;\n    const placeholders=list.map(()=>'?').join(',');\n    await db().batch([\n      db().prepare('UPDATE audio_budget SET used_bytes=used_bytes-(SELECT COALESCE(SUM(size),0) FROM audio_objects WHERE key IN ('+placeholders+')) WHERE id=1').bind(...list),\n      db().prepare('DELETE FROM audio_objects WHERE key IN ('+placeholders+')').bind(...list)\n    ]);\n  }\n};}\n"
  }
];
  for (const file of databaseRepair) {
    const currentHash = createHash('sha256').update(readFileSync(file.path)).digest('hex');
    if (currentHash !== file.originalHash && currentHash !== file.fixedHash) {
      fail(`${file.path} has unexpected changes. Deployment stopped to preserve them.`);
    }
  }
  for (const file of databaseRepair) writeFileSync(file.path, file.contents);
  console.log('Applied database repair: simple SQL migration and atomic recording storage limits.');
  const sqlCheck = new DatabaseSync(':memory:');
  try {
    for (const name of ['0000_nostalgic_polaris.sql', '0001_moaning_talisman.sql', '0002_cloudflare_accounts.sql']) {
      const sql = readFileSync(`drizzle/${name}`, 'utf8');
      if (/CREATE\s+TRIGGER/i.test(sql)) fail('Unexpected database trigger. Deployment stopped.');
      sqlCheck.exec(sql);
    }
  } finally { sqlCheck.close(); }
  console.log('Database migration syntax verified locally.');
  const config = readJson('wrangler.json');
  if (config.r2_buckets?.length) fail('Unexpected R2 storage binding. Deployment stopped.');
  const database = config.d1_databases?.find(d => d.binding === 'DB');
  if (!database) fail('The game’s DB binding is missing.');
  config.name = 'vocaquest';
  config.account_id = accountId;
  config.workers_dev = true;
  database.database_id = databaseId;
  writeFileSync('wrangler.json', JSON.stringify(config, null, 2) + '\n');
  console.log('Configured VocaQuest for the existing D1 database; no R2 subscription is used.');

  if (!process.argv.includes('--prepare-only')) {
    process.env.CLOUDFLARE_CF_FETCH_ENABLED = 'false';
    process.env.WRANGLER_SEND_METRICS = 'false';
    run(process.execPath, ['scripts/run-framework.mjs', 'build']);
    const output = readJson('dist/server/wrangler.json');
    const outputDb = output.d1_databases?.find(d => d.binding === 'DB');
    if (output.name !== 'vocaquest' || outputDb?.database_id !== databaseId || output.r2_buckets?.length) {
      fail('The generated deployment settings do not match VocaQuest and its D1 database.');
    }
    console.log('Build verified. Cloudflare can now run npm run deploy:cloudflare.');
  }
} catch (error) {
  console.error(`VocaQuest setup: ${error.message}`);
  process.exitCode = 1;
}
