# Connect recordings to Google Drive

The ChatGPT Google Drive connection has access to the private **VocaQuest Recordings** folder owned by amina.m.qatan@gmail.com. The public game needs its own server connection; it cannot use ChatGPT's credentials.

1. Open https://script.google.com/home/start in a browser, signed in as **amina.m.qatan@gmail.com**. Create a new project named **VocaQuest Recordings**.
2. Replace the contents of `Code.gs` with the supplied `docs/google-drive/Code.gs` file. Save.
3. Select `setupVocaQuestDrive` in the function menu and click **Run**. Review and approve Google's Drive access request for your own script. The execution log shows `DRIVE_BRIDGE_KEY`; keep it private.
4. Click **Deploy → New deployment → Web app**. Set **Execute as: Me** and **Who has access: Anyone**. Deploy and copy the **Web app URL** ending `/exec`.
5. In the VocaQuest Codespace terminal run `npm run connect:drive`. Paste the Web app URL, then the private bridge key when requested. The key is entered without showing it and stored as a Cloudflare secret.
6. Sign into the deployed game as a student, finish a unit, record and upload. Confirm that a new file appears in the private folder, then check playback from Learning Skills Marks.

The web endpoint verifies a timestamped HMAC signature on every operation. It accepts only VocaQuest recording keys and accesses only the configured folder. Do not share the folder publicly or put either secret in GitHub. Students do not need Google accounts. The supplied script's `doGet` never returns a recording.

New recordings use Drive after the connection is configured. Older D1 recordings stay accessible. Teacher deletion moves Drive recordings to the Drive bin; Google storage is recovered when the bin is emptied. Drive capacity and Apps Script quotas still apply. If the college blocks web apps with access set to Anyone, the owner must use an allowed account or an approved alternative; do not bypass that policy.

Private folder: https://drive.google.com/drive/folders/1ya4exAaV8V7_xVNlkFeScavFDWjZ-BbC

References: https://developers.google.com/apps-script/guides/web and https://developers.google.com/apps-script/guides/services/quotas
