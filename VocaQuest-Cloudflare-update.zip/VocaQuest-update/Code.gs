/** VocaQuest private recording bridge. Paste into your own Google Apps Script project. */
const VOCAQUEST_FOLDER = '1ya4exAaV8V7_xVNlkFeScavFDWjZ-BbC';

/** Run once while signed in as amina.m.qatan@gmail.com. Save the key privately. */
function setupVocaQuestDrive() {
  const properties = PropertiesService.getScriptProperties();
  let key = properties.getProperty('VOCAQUEST_BRIDGE_KEY');
  if (!key) { key = Utilities.getUuid() + Utilities.getUuid(); properties.setProperty('VOCAQUEST_BRIDGE_KEY', key); }
  const folder = DriveApp.getFolderById(VOCAQUEST_FOLDER);
  console.log('Folder: ' + folder.getName());
  console.log('Save this privately as the Cloudflare secret DRIVE_BRIDGE_KEY: ' + key);
}

function doGet() { return reply_({ok:false,error:'This is a private VocaQuest recording service.'}); }
function doPost(event) {
  try {
    const raw = event && event.postData && event.postData.contents;
    if (!raw || raw.length > 18 * 1024 * 1024) throw new Error('Invalid request.');
    const envelope = JSON.parse(raw), secret = PropertiesService.getScriptProperties().getProperty('VOCAQUEST_BRIDGE_KEY');
    if (!secret || typeof envelope.payload !== 'string' || typeof envelope.signature !== 'string') throw new Error('Access denied.');
    const expected = Utilities.base64Encode(Utilities.computeHmacSha256Signature(envelope.payload, secret));
    if (!equal_(expected, envelope.signature)) throw new Error('Access denied.');
    const data = JSON.parse(envelope.payload);
    if (typeof data.time !== 'number' || Math.abs(Date.now()-data.time)>300000 || !/^[a-f0-9-]{36}$/.test(data.nonce||'')) throw new Error('Expired request.');
    const lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      const cache=CacheService.getScriptCache();
      if(cache.get(data.nonce))throw new Error('Request already used.');
      cache.put(data.nonce,'1',600);
      const folder = DriveApp.getFolderById(VOCAQUEST_FOLDER);
      if (data.action === 'delete') {
        if (!Array.isArray(data.keys) || data.keys.length>100) throw new Error('Invalid recording selection.');
        data.keys.forEach(key => { const files=folder.getFilesByName(fileName_(key));while(files.hasNext())files.next().setTrashed(true); });
        return reply_({ok:true});
      }
      const filename=fileName_(data.key), files=folder.getFilesByName(filename);
      if (data.action === 'put') {
        if (!['audio/webm','audio/ogg','audio/mp4','audio/wav','audio/x-wav'].includes(String(data.mime).split(';')[0]) || typeof data.audio!=='string') throw new Error('Invalid audio.');
        const bytes=Utilities.base64Decode(data.audio);
        if(!bytes.length||bytes.length>12*1024*1024)throw new Error('Recording exceeds 12 MB.');
        // A retry keeps the original file; each upload already has a unique random key.
        if(!files.hasNext())folder.createFile(Utilities.newBlob(bytes,data.mime,filename));
        return reply_({ok:true});
      }
      if(data.action==='get'){
        if(!files.hasNext())return reply_({ok:true,found:false});
        const file=files.next();if(file.getSize()>12*1024*1024)throw new Error('Recording exceeds 12 MB.');
        return reply_({ok:true,found:true,size:file.getSize(),audio:Utilities.base64Encode(file.getBlob().getBytes())});
      }
      throw new Error('Unknown request.');
    } finally {lock.releaseLock();}
  } catch(error) { return reply_({ok:false,error:String(error.message||'Recording request failed.')}); }
}
function fileName_(key){
  if(typeof key!=='string'||!/^drive\/[a-f0-9-]{36}\/[a-f0-9-]{36}$/.test(key))throw new Error('Invalid recording key.');
  return 'vq-'+Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,key)).replace(/=+$/,'');
}
function equal_(a,b){if(a.length!==b.length)return false;let difference=0;for(let i=0;i<a.length;i++)difference|=a.charCodeAt(i)^b.charCodeAt(i);return difference===0;}
function reply_(data){return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);}
