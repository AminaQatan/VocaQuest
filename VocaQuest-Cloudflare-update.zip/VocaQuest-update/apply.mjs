import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
const patch=fileURLToPath(new URL('./update.patch',import.meta.url));
if(!existsSync('.git')||!existsSync('package.json'))throw new Error('Run this from your VocaQuest repository terminal.');
const check=spawnSync('git',['apply','--check',patch],{encoding:'utf8'});
if(check.status!==0){
 const applied=spawnSync('git',['apply','--reverse','--check',patch],{encoding:'utf8'});
 if(applied.status!==0){console.error(check.stderr);throw new Error('Your files differ from the exported game. Nothing was changed. Send the error text for help.');}
 console.log('The Cloudflare update is already applied. Continuing setup.');
}else{const applied=spawnSync('git',['apply',patch],{stdio:'inherit'});if(applied.status!==0)process.exit(applied.status||1);console.log('VocaQuest Cloudflare update applied.');}
const setup=spawnSync(process.execPath,['scripts/cloudflare-setup.mjs'],{stdio:'inherit'});process.exit(setup.status||0);
