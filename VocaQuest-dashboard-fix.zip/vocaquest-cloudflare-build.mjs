// Cloudflare dashboard build command: node vocaquest-cloudflare-build.mjs
// Build variable: VOCAQUEST_D1_ID = the ID of your existing vocaquest-db database.
// Deploy command: npm run deploy:cloudflare
// This script prepares and builds the game. It never starts an interactive login.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

const archive = 'VocaQuest-Cloudflare-update.zip';
const patch = 'VocaQuest-update/update.patch';
const archiveHash = '79a715c7cb5cbdca4f0146e3b25addb4c87560df648f144f852d6540d0704aa5';
const patchHash = '460b1361f935aa6c207c33f84d96cb152db0e16e9230bdd195b238ea46308569';
const accountId = '3332515a8819ec6238d719a2c85d698d';
const placeholder = '00000000-0000-4000-8000-000000000000';
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function fail(message) { throw new Error(message); }
function readJson(path) { return JSON.parse(readFileSync(path, 'utf8')); }
function run(command, args) {
  const result = spawnSync(command, args, { stdio: 'inherit', env: process.env });
  if (result.error) throw result.error;
  if (result.status !== 0) fail(`${command} failed; deployment stopped. See the preceding error.`);
}
function checkHash(path, expected) {
  const actual = createHash('sha256').update(readFileSync(path)).digest('hex');
  if (actual !== expected) fail(`${path} does not match the verified VocaQuest update.`);
}

try {
  if (process.argv.slice(2).some(arg => arg !== '--prepare-only')) fail('Unknown option.');
  if (!existsSync('package.json') || !existsSync('app/page.tsx')) {
    fail('Run this build from the VocaQuest repository root.');
  }
  const existing = existsSync('wrangler.json') ? readJson('wrangler.json') : {};
  const databaseId = (process.env.VOCAQUEST_D1_ID || existing.d1_databases?.find(d => d.binding === 'DB')?.database_id || '').trim();
  if (!uuid.test(databaseId) || databaseId === placeholder) {
    fail('Add VOCAQUEST_D1_ID in Cloudflare Settings > Build > Variables and secrets. Use the Database ID from your existing vocaquest-db database.');
  }
  if (process.env.CLOUDFLARE_ACCOUNT_ID && process.env.CLOUDFLARE_ACCOUNT_ID !== accountId) {
    fail('This build belongs to Amina Qatan’s VocaQuest Cloudflare account. Check the selected account.');
  }
  const alreadyUpdated = existsSync('app/auth.ts') && existsSync('app/api/session/route.ts') &&
    existsSync('lib/audio-storage.ts') && existsSync('scripts/cloudflare-deploy.mjs') &&
    readJson('package.json').scripts?.['deploy:cloudflare'] === 'node scripts/cloudflare-deploy.mjs';
  if (!alreadyUpdated) {
    if (!existsSync(archive)) fail(`Upload ${archive} to the repository root first.`);
    checkHash(archive, archiveHash);
    run('unzip', ['-o', archive]);
    checkHash(patch, patchHash);
    run('git', ['apply', '--check', patch]);
    run('git', ['apply', patch]);
    console.log('Applied the verified standalone VocaQuest update.');
  }
  if (existsSync('app/chatgpt-auth.ts') || !existsSync('app/sign-in/page.tsx')) {
    fail('The standalone sign-in update is incomplete. Deployment stopped.');
  }
  const config = readJson('wrangler.json');
  if (config.r2_buckets?.length) fail('Unexpected R2 storage binding. Deployment stopped.');
  const database = config.d1_databases?.find(d => d.binding === 'DB');
  if (!database) fail('The game’s DB binding is missing.');
  config.name = 'vocaquest';
  config.account_id = accountId;
  config.workers_dev = true;
  database.database_id = databaseId;
  writeFileSync('wrangler.json', JSON.stringify(config, null, 2) + '\n');
  console.log('Configured VocaQuest for the existing D1 database; no R2 subscription is used.');

  if (!process.argv.includes('--prepare-only')) {
    process.env.CLOUDFLARE_CF_FETCH_ENABLED = 'false';
    process.env.WRANGLER_SEND_METRICS = 'false';
    run(process.execPath, ['scripts/run-framework.mjs', 'build']);
    const output = readJson('dist/server/wrangler.json');
    const outputDb = output.d1_databases?.find(d => d.binding === 'DB');
    if (output.name !== 'vocaquest' || outputDb?.database_id !== databaseId || output.r2_buckets?.length) {
      fail('The generated deployment settings do not match VocaQuest and its D1 database.');
    }
    console.log('Build verified. Cloudflare can now run npm run deploy:cloudflare.');
  }
} catch (error) {
  console.error(`VocaQuest setup: ${error.message}`);
  process.exitCode = 1;
}
